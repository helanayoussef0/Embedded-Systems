#include "LPC17xx.h"
#include <stdio.h>
#include "Board_Led.h"
#include "GPIO_LPC17xx.h"

//------- ITM Stimulus Port definitions for printf ------------------- //
#define ITM_Port8(n)    (*((volatile unsigned char *)(0xE0000000+4*n)))
#define ITM_Port16(n)   (*((volatile unsigned short*)(0xE0000000+4*n)))
#define ITM_Port32(n)   (*((volatile unsigned long *)(0xE0000000+4*n)))

#define DEMCR           (*((volatile unsigned long *)(0xE000EDFC)))
#define TRCENA          0x01000000
#define DELAY_50 166

int32_t Joystick_Initialize();
int32_t LED_Initialize();

struct __FILE { int handle;  };
FILE __stdout;
FILE __stdin;

int fputc(int ch, FILE *f) {
  if (DEMCR & TRCENA) {
    while (ITM_Port32(0) == 0);
    ITM_Port8(0) = ch;
  }
  return(ch);
}

static void delay (void){
	printf("In delay\n");
	int i = 0;
	while(i != DELAY_50){
		i++;
	}
}
//------------------------------------------------------------------- //

// Bit Band Macros used to calculate the alias address at run time
#define ADDRESS(x)    (*((volatile unsigned long *)(x)))
#define BitBand(x, y) 	ADDRESS(((unsigned long)(x) & 0xF0000000) | 0x02000000 |(((unsigned long)(x) & 0x000FFFFF) << 5) | ((y) << 2))
#define ADCR_P131 (*((volatile unsigned long *)0x233806FC))
#define ADCR_P204 (*((volatile unsigned long *)0x23380A90))
#define ADCR_Bit24   (*((volatile unsigned long *)0x42680060))

volatile unsigned long * bit0;
volatile unsigned long * bit1;

int main(void){
	
	
	delay();
	int conditionalID = 0;
	//mask mode
	if (conditionalID++ == 0){  
		printf("\nMask mode\n");
		LPC_GPIO1 -> FIOPIN |= 1UL<<31;
		LPC_GPIO2 -> FIOPIN |= 1UL<<4;
		printf("LEDs on\n");
		delay();
		LPC_GPIO1 -> FIOPIN &= ~(1UL<<31);
		LPC_GPIO2 -> FIOPIN &= ~(1UL<<4);
		printf("LEDs off\n");

	}
	//function mode	
	if (conditionalID++ == 1){
	printf("\nfunction mode\n");
  bit0 = &BitBand(&LPC_GPIO1->FIOPIN, 29);		
 *bit0 = 1;
	bit1 = &BitBand(&LPC_GPIO2->FIOPIN, 3);
 *bit1 = 1;
	printf("LEDs on\n");
  delay();
 *bit0 = 0;
 *bit1 = 0;
	printf("LEDs off\n\n");
	}
	//bit band mode
	if (conditionalID++ == 2){
	printf("\nBit Masking mode\n");
	ADCR_P131 = 1;
  ADCR_P204 = 1;
	printf("LEDs on\n");
  delay();
	ADCR_P131 = 0;
	ADCR_P204 = 0;
	printf("LEDs off\n\n");
	}
	if (conditionalID++ == 3){
	printf("\nBarrel Shift mode\n");
	int r1 = 1, r2 = 0, r3 = 5;
	while(r2 <= 0x18){
		if((r1 - r2) > 0){
		r1 = r1 + 2;
		r2 = r1 + (r3*4);
		r3 = r3/2;
	}
	else{
		r2 = r2 + 1;
	}
	LPC_GPIO1 -> FIOPIN |= 1UL<<28;
	LPC_GPIO2 -> FIOPIN |= 1UL<<5;
	printf("LEDs on\n");
	delay();
	LPC_GPIO1 -> FIOPIN &= 1UL<<28;
	LPC_GPIO2 -> FIOPIN &= 1UL<<5;
	printf("LEDs off\n\n");
		}
	}
	return 0;
}

